/*
 * LED_config.h
 *
 *  Created on: Aug 16, 2019
 *      Author: minanabil
 */

/*
 * this file for configuring the driver itself as leds pins and its mode */

#ifndef LED_CONFIG_H_
#define LED_CONFIG_H_

#define LED_0_mode FORWARD
#define LED_1_mode FORWARD
#define LED_2_mode FORWARD
#define LED_3_mode FORWARD
#define LED_4_mode FORWARD
#define LED_5_mode FORWARD
#define LED_6_mode FORWARD
#define LED_7_mode FORWARD
#define LED_8_mode FORWARD
#define LED_9_mode FORWARD
#define LED_10_mode FORWARD
#define LED_11_mode FORWARD
#define LED_12_mode FORWARD
#define LED_13_mode FORWARD
#define LED_14_mode FORWARD
#define LED_15_mode FORWARD
#define LED_16_mode FORWARD
#define LED_17_mode FORWARD
#define LED_18_mode FORWARD
#define LED_19_mode FORWARD
#define LED_20_mode FORWARD
#define LED_21_mode FORWARD
#define LED_22_mode FORWARD
#define LED_23_mode FORWARD
#define LED_24_mode FORWARD
#define LED_25_mode FORWARD
#define LED_26_mode FORWARD
#define LED_27_mode FORWARD
#define LED_28_mode FORWARD
#define LED_29_mode FORWARD
#define LED_30_mode FORWARD
#define LED_31_mode FORWARD

#define LEDPIN_0 PIN_0
#define LEDPIN_1 PIN_1
#define LEDPIN_2 PIN_2
#define LEDPIN_3 PIN_3
#define LEDPIN_4 PIN_4
#define LEDPIN_5 PIN_5
#define LEDPIN_6 PIN_6
#define LEDPIN_7 PIN_7
#define LEDPIN_8 PIN_8
#define LEDPIN_9 PIN_9
#define LEDPIN_10 PIN_10
#define LEDPIN_11 PIN_11
#define LEDPIN_12 PIN_12
#define LEDPIN_13 PIN_13
#define LEDPIN_14 PIN_14
#define LEDPIN_15 PIN_15
#define LEDPIN_16 PIN_16
#define LEDPIN_17 PIN_17
#define LEDPIN_18 PIN_18
#define LEDPIN_19 PIN_19
#define LEDPIN_20 PIN_20
#define LEDPIN_21 PIN_21
#define LEDPIN_22 PIN_22
#define LEDPIN_23 PIN_23
#define LEDPIN_24 PIN_24
#define LEDPIN_25 PIN_25
#define LEDPIN_26 PIN_26
#define LEDPIN_27 PIN_27
#define LEDPIN_28 PIN_28
#define LEDPIN_29 PIN_29
#define LEDPIN_30 PIN_30
#define LEDPIN_31 PIN_31


#endif /* LED_CONFIG_H_ */
