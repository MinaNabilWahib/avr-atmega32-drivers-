/*
 * DIO_priv.h
 *
 *  Created on: Aug 16, 2019
 *      Author: minanabil
 */

#ifndef DIO_PRIV_H_
#define DIO_PRIV_H_

#define IN  0
#define OUT 1


#endif /* DIO_PRIV_H_ */
