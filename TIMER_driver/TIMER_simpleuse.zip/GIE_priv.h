/*********************************************/
/* Author  : Hussein Elmasry		         */
/* Date    : 24/2/2018				         */
/* Version : V01						     */
/*********************************************/

#ifndef _GIE_PRIV_H
#define _GIE_PRIV_H


#define GIE_u8_BIT_INDEX	            7


#endif
