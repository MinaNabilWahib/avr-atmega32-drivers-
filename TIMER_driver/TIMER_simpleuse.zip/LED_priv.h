/*
 * LED_priv.h
 *
 *  Created on: Aug 16, 2019
 *      Author: minanabil
 */

#ifndef LED_PRIV_H_
#define LED_PRIV_H_

#define FORWARD 1
#define REVERSE 0

#endif /* LED_PRIV_H_ */
