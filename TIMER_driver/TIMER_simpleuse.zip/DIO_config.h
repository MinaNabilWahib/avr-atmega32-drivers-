/*
 * DIO_config.h
 *
 *  Created on: Aug 16, 2019
 *      Author: minanabil
 */

#ifndef DIO_CONFIG_H_
#define DIO_CONFIG_H_

#define PIN_0DIR OUT
#define PIN_1DIR OUT
#define PIN_2DIR OUT
#define PIN_3DIR OUT
#define PIN_4DIR OUT
#define PIN_5DIR IN
#define PIN_6DIR IN
#define PIN_7DIR OUT
#define PIN_8DIR IN
#define PIN_9DIR IN
#define PIN_10DIR IN
#define PIN_11DIR IN
#define PIN_12DIR OUT
#define PIN_13DIR IN
#define PIN_14DIR IN
#define PIN_15DIR IN
#define PIN_16DIR IN
#define PIN_17DIR IN
#define PIN_18DIR IN
#define PIN_19DIR IN
#define PIN_20DIR IN
#define PIN_21DIR IN
#define PIN_22DIR IN
#define PIN_23DIR IN
#define PIN_24DIR IN
#define PIN_25DIR IN
#define PIN_26DIR IN
#define PIN_27DIR IN
#define PIN_28DIR IN
#define PIN_29DIR IN
#define PIN_30DIR IN
#define PIN_31DIR IN



#endif /* DIO_CONFIG_H_ */
