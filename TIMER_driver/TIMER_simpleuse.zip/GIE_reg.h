/*********************************************/
/* Author  : Hussein Elmasry		         */
/* Date    : 24/2/2018				         */
/* Version : V01						     */
/*********************************************/

#ifndef _GIE_REG_H
#define _GIE_REG_H

#define SREG	*((volatile u8*)0x5F)

#endif